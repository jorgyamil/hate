Para francesca
